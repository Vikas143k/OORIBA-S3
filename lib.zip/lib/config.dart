class Config {
  static const String apiUrl =
      'http://localhost:3000/send-email'; // Use your server's IP or domain
  static const String serviceId = 'service_z0soilk';
  static const String templateId = 'template_q66bo0j';
  static const String userId = '_b8-qaQnQOhviU59X';
}